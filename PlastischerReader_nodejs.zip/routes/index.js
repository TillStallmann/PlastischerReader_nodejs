var axios = require('axios');
var express = require('express');
var router = express.Router();
var qs = require('qs');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/GetTokenAndSubdomain', function(req, res) {
  try {
    var config ={
      headers: {
        'content-type': 'application/x-www-form-urlencoded'
      }
    }
    var data = {
      grant_type: 'client_credentials',
      client_id: process.env.CLIENT_ID,
      client_secret: process.env.CLIENT_SECRET,
      resource: 'https://cognitiveservices.azure.com/'
    };
    var url = `https://login.windows.net/${process.env.TENANT_ID}/oauth2/token`
    console.log(qs.stringify(data));
    axios.post(url, qs.stringify(data), config)
        .then(function (response) {
          var token = response.data.access_token;
          var subdomain = process.env.SUBDOMAIN;
          return res.send({token, subdomain});
        })
        .catch(function (response) {
          if (response.status !== 200) {
            return res.send({error :  "Unable to acquire Azure AD token. Check the debugger for more information."})
          }
        });
  } catch (error) {
    console.log(error);
    return res.status(500).send('CogSvcs IssueToken error');
  }
});

module.exports = router;